import { appConstants } from '../helpers/app-constants';

export function response(state = {}, action) {
  return action;
}